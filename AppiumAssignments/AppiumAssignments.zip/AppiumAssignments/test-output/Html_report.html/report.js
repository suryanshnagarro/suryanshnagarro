$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("customview.feature");
formatter.feature({
  "line": 3,
  "name": "Validate different options",
  "description": "",
  "id": "validate-different-options",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 7,
  "name": "Validate the custom view",
  "description": "",
  "id": "validate-different-options;validate-the-custom-view",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 6,
      "name": "@tag8"
    }
  ]
});
formatter.step({
  "line": 8,
  "name": "I open application",
  "keyword": "Given "
});
formatter.step({
  "line": 9,
  "name": "I tap on Accessiblity",
  "keyword": "When "
});
formatter.step({
  "line": 10,
  "name": "I validate custom view",
  "keyword": "Then "
});
formatter.match({
  "location": "customview.i_open_application()"
});
formatter.result({
  "duration": 9788971300,
  "status": "passed"
});
formatter.match({
  "location": "customview.i_tap_on_Accessiblity()"
});
formatter.result({
  "duration": 1942450800,
  "status": "passed"
});
formatter.match({
  "location": "customview.i_validate_custom_view()"
});
formatter.result({
  "duration": 1196486900,
  "status": "passed"
});
formatter.uri("displaytitle.feature");
formatter.feature({
  "line": 2,
  "name": "Validate display options",
  "description": "",
  "id": "validate-display-options",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 6,
  "name": "Validate DisplayShowtitle option",
  "description": "",
  "id": "validate-display-options;validate-displayshowtitle-option",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 5,
      "name": "@tag3"
    }
  ]
});
formatter.step({
  "line": 7,
  "name": "I open the application",
  "keyword": "Given "
});
formatter.step({
  "line": 8,
  "name": "I tap on App",
  "keyword": "When "
});
formatter.step({
  "line": 9,
  "name": "I tap on Action Bar",
  "keyword": "When "
});
formatter.step({
  "line": 10,
  "name": "I tap on Display options",
  "keyword": "Then "
});
formatter.step({
  "line": 11,
  "name": "I tap on Display show title",
  "keyword": "Then "
});
formatter.match({
  "location": "hidingshowingbuttons.i_open_the_application()"
});
formatter.result({
  "duration": 9912779800,
  "status": "passed"
});
formatter.match({
  "location": "displaytitle.i_tap_on_App()"
});
formatter.result({
  "duration": 11860045400,
  "status": "passed"
});
formatter.match({
  "location": "displaytitle.i_tap_on_Action_Bar()"
});
formatter.result({
  "duration": 1312487200,
  "status": "passed"
});
formatter.match({
  "location": "displaytitle.i_tap_on_Display_opstions()"
});
formatter.result({
  "duration": 1272758400,
  "status": "passed"
});
formatter.match({
  "location": "displaytitle.i_tap_on_Display_show_title()"
});
formatter.result({
  "duration": 68674300,
  "status": "passed"
});
formatter.uri("hidingbuttons.feature");
formatter.feature({
  "line": 2,
  "name": "Validate different opstions",
  "description": "",
  "id": "validate-different-opstions",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 6,
  "name": "Validate Hiding of buttons",
  "description": "",
  "id": "validate-different-opstions;validate-hiding-of-buttons",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 5,
      "name": "@tag1"
    }
  ]
});
formatter.step({
  "line": 7,
  "name": "I open the application",
  "keyword": "Given "
});
formatter.step({
  "line": 8,
  "name": "I tap on Animation",
  "keyword": "When "
});
formatter.step({
  "line": 9,
  "name": "I tap on Hide-Show Animations",
  "keyword": "When "
});
formatter.step({
  "line": 10,
  "name": "I validate the hiding of buttons",
  "keyword": "Then "
});
formatter.match({
  "location": "hidingshowingbuttons.i_open_the_application()"
});
formatter.result({
  "duration": 10211709800,
  "status": "passed"
});
formatter.match({
  "location": "hidingshowingbuttons.i_tap_on_Animation()"
});
formatter.result({
  "duration": 625181200,
  "status": "passed"
});
formatter.match({
  "location": "hidingshowingbuttons.i_tap_on_Hide_Show_Animations()"
});
formatter.result({
  "duration": 2617949300,
  "status": "passed"
});
formatter.match({
  "location": "hidingshowingbuttons.i_validate_the_hiding_of_buttons()"
});
formatter.result({
  "duration": 221844600,
  "status": "passed"
});
formatter.uri("showbuttons.feature");
formatter.feature({
  "line": 3,
  "name": "Validate showing of buttons",
  "description": "",
  "id": "validate-showing-of-buttons",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 7,
  "name": "Validate showing of buttons",
  "description": "",
  "id": "validate-showing-of-buttons;validate-showing-of-buttons",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 6,
      "name": "@tag2"
    }
  ]
});
formatter.step({
  "line": 8,
  "name": "I open the application",
  "keyword": "Given "
});
formatter.step({
  "line": 9,
  "name": "I tap on Animation",
  "keyword": "When "
});
formatter.step({
  "line": 10,
  "name": "I tap on Hide-Show Animations",
  "keyword": "When "
});
formatter.step({
  "line": 11,
  "name": "I tap on first button",
  "keyword": "When "
});
formatter.step({
  "line": 12,
  "name": "I validate the showing of buttons",
  "keyword": "Then "
});
formatter.match({
  "location": "hidingshowingbuttons.i_open_the_application()"
});
formatter.result({
  "duration": 10015720100,
  "status": "passed"
});
formatter.match({
  "location": "hidingshowingbuttons.i_tap_on_Animation()"
});
formatter.result({
  "duration": 1880369700,
  "status": "passed"
});
formatter.match({
  "location": "hidingshowingbuttons.i_tap_on_Hide_Show_Animations()"
});
formatter.result({
  "duration": 1304258100,
  "status": "passed"
});
formatter.match({
  "location": "hidingshowingbuttons.i_tap_on_first_button()"
});
formatter.result({
  "duration": 100769700,
  "status": "passed"
});
formatter.match({
  "location": "hidingshowingbuttons.i_validate_the_showing_of_buttons()"
});
formatter.result({
  "duration": 88973300,
  "status": "passed"
});
formatter.uri("smsmessage.feature");
formatter.feature({
  "line": 2,
  "name": "Verify sms messaging",
  "description": "",
  "id": "verify-sms-messaging",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "line": 6,
  "name": "send sms message",
  "description": "",
  "id": "verify-sms-messaging;send-sms-message",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 5,
      "name": "@tag6"
    }
  ]
});
formatter.step({
  "line": 7,
  "name": "Launch APIDemos.apk on the device.",
  "keyword": "Given "
});
formatter.step({
  "line": 8,
  "name": "Tap on OS.",
  "keyword": "Then "
});
formatter.step({
  "line": 9,
  "name": "Tap on SMS Messaging",
  "keyword": "Then "
});
formatter.step({
  "line": 10,
  "name": "Enter the number \"\u003cNumber\u003e\"",
  "keyword": "Then "
});
formatter.step({
  "line": 11,
  "name": "Enter the message \"\u003cMessage\u003e\"",
  "keyword": "Then "
});
formatter.step({
  "line": 12,
  "name": "click on send",
  "keyword": "Then "
});
formatter.examples({
  "line": 13,
  "name": "",
  "description": "",
  "id": "verify-sms-messaging;send-sms-message;",
  "rows": [
    {
      "cells": [
        "Number",
        "Message"
      ],
      "line": 14,
      "id": "verify-sms-messaging;send-sms-message;;1"
    },
    {
      "cells": [
        "9616561186",
        "hello"
      ],
      "line": 15,
      "id": "verify-sms-messaging;send-sms-message;;2"
    }
  ],
  "keyword": "Examples"
});
formatter.scenario({
  "line": 15,
  "name": "send sms message",
  "description": "",
  "id": "verify-sms-messaging;send-sms-message;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 5,
      "name": "@tag6"
    }
  ]
});
formatter.step({
  "line": 7,
  "name": "Launch APIDemos.apk on the device.",
  "keyword": "Given "
});
formatter.step({
  "line": 8,
  "name": "Tap on OS.",
  "keyword": "Then "
});
formatter.step({
  "line": 9,
  "name": "Tap on SMS Messaging",
  "keyword": "Then "
});
formatter.step({
  "line": 10,
  "name": "Enter the number \"9616561186\"",
  "matchedColumns": [
    0
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 11,
  "name": "Enter the message \"hello\"",
  "matchedColumns": [
    1
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 12,
  "name": "click on send",
  "keyword": "Then "
});
formatter.match({
  "location": "smsmessage.launch_APIDemos_apk_on_the_device()"
});
formatter.result({
  "duration": 10169750400,
  "status": "passed"
});
formatter.match({
  "location": "smsmessage.tap_on_OS()"
});
formatter.result({
  "duration": 1845944600,
  "status": "passed"
});
formatter.match({
  "location": "smsmessage.tap_on_SMS_Messaging()"
});
formatter.result({
  "duration": 1409238100,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "9616561186",
      "offset": 18
    }
  ],
  "location": "smsmessage.enter_the_number(String)"
});
formatter.result({
  "duration": 169159000,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "hello",
      "offset": 19
    }
  ],
  "location": "smsmessage.enter_the_message(String)"
});
formatter.result({
  "duration": 657396500,
  "status": "passed"
});
formatter.match({
  "location": "smsmessage.click_on_send()"
});
formatter.result({
  "duration": 567594200,
  "status": "passed"
});
});