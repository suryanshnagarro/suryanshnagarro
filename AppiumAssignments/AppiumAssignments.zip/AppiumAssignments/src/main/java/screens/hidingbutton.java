package screens;

import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;

public class hidingbutton {
	AppiumDriver<MobileElement> driver;
	public hidingbutton(AppiumDriver<MobileElement> driver) {
		PageFactory.initElements(driver, this);
		this.driver=driver;
	}



@AndroidFindBy(xpath="//android.widget.TextView[@content-desc=\\\"Animation\\\"]")
public MobileElement Animation;
@AndroidFindBy(xpath="//android.widget.TextView[@content-desc=\\\"Hide-Show Animations\"]")
public MobileElement HideShowAnimations;
@AndroidFindBy(xpath="\\r\\n\"\r\n"
		+ "				+ \"/hierarchy/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout[2]/android.widget.LinearLayout/android.widget.LinearLayout[3]/android.widget.Button[1]")
public MobileElement Button1;

public void clickAnimation() {
		Animation.click();
}
public void clickHideshow() {
	HideShowAnimations.click();
}
public void clickbuttons() {
	Button1.click();
}}

	
	