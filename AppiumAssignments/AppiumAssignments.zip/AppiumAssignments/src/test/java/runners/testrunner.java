package runners;
import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;


@CucumberOptions(
		features="src/test/java/Features",
		glue={"stepdefnitions"},
		plugin = {"pretty","html:test-output/Html_report.html",
				"junit:junit_xml/junit.xml",
				"json:Json_xml/cucumber.json"},
monochrome=true,
dryRun=false,
strict=false,
tags= {"@tag8,@tag1,@tag2,@tag3,@tag6"})
public class testrunner extends AbstractTestNGCucumberTests{

}




