package stepdefnitions;

import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.DesiredCapabilities;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

public class customview {
	private static AppiumDriver<MobileElement> driver;

@Given("^I open application$")
public void i_open_application() throws Throwable {
	

{DesiredCapabilities capabilties = new DesiredCapabilities();
	
	capabilties.setCapability("platformName", "Android");
	capabilties.setCapability("platformVersion", "8.1");
	capabilties.setCapability("appPackage", "io.appium.android.apis");
	capabilties.setCapability("appActivity", ".ApiDemos");
	capabilties.setCapability("deviceName", "Android");
	capabilties.setCapability("app", "/Users/suryanshrastogi/Downloads/ApiDemos-debug.apk");
	
	try {
		driver = new AndroidDriver(new URL(("http://0.0.0.0:4723/wd/hub")),capabilties);
		driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);

		}catch (Exception e) {
		e.printStackTrace();
		}
}
}

@When("^I tap on Accessiblity$")
public void i_tap_on_Accessiblity() throws Throwable {
	driver.findElement(By.xpath("//android.widget.TextView[@content-desc=\"Accessibility\"]")).click();
    
}

@Then("^I validate custom view$")
public void i_validate_custom_view() throws Throwable {

	driver.findElement(By.xpath("//android.widget.TextView[@content-desc=\"Custom View\"]")).click();
    
}

}
