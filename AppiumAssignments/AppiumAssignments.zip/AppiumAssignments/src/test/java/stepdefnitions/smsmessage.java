package stepdefnitions;

import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.DesiredCapabilities;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.service.local.AppiumDriverLocalService;

public class smsmessage {
	private static AppiumDriver<MobileElement> driver;
	public static AppiumDriverLocalService service;

	@Given("^Launch APIDemos\\.apk on the device\\.$")
	public void launch_APIDemos_apk_on_the_device() throws Throwable {
DesiredCapabilities capabilties = new DesiredCapabilities();
		
		capabilties.setCapability("platformName", "Android");
		capabilties.setCapability("platformVersion", "8.1");
		capabilties.setCapability("appPackage", "io.appium.android.apis");
		capabilties.setCapability("appActivity", ".ApiDemos");
		capabilties.setCapability("deviceName", "Android");
		capabilties.setCapability("app", "/Users/suryanshrastogi/Downloads/ApiDemos-debug.apk");
		
		try {
			driver = new AndroidDriver(new URL(("http://0.0.0.0:4723/wd/hub")),capabilties);
			driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);

			}catch (Exception e) {
			e.printStackTrace();
			}

	    
	  
	 
	   
	}
	    
	    
	

	@Then("^Tap on OS\\.$")
	public void tap_on_OS() throws Throwable {
		driver.findElement(By.xpath("//android.widget.TextView[@content-desc=\"OS\"]")).click();
	   
	}

	@Then("^Tap on SMS Messaging$")
	public void tap_on_SMS_Messaging() throws Throwable {
		driver.findElement(By.xpath("//android.widget.TextView[@content-desc=\"SMS Messaging\"]")).click();
	   
	}

@Then("^Enter the number \"([^\"]*)\"$")
public void enter_the_number(String arg1) throws Throwable {
	driver.findElement(By.xpath("	\r\n"
			+ "/hierarchy/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout[2]/android.widget.ScrollView/android.widget.LinearLayout/android.widget.TableLayout/android.widget.TableRow[1]/android.widget.EditText")).sendKeys(arg1);
    
    
}

@Then("^Enter the message \"([^\"]*)\"$")
public void enter_the_message(String arg1) throws Throwable {
	driver.findElement(By.xpath("	\r\n"
			+ "/hierarchy/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout[2]/android.widget.ScrollView/android.widget.LinearLayout/android.widget.TableLayout/android.widget.TableRow[2]/android.widget.EditText")).sendKeys(arg1);
    
    
	
}

@Then("^click on send$")
public void click_on_send() throws Throwable {
	driver.findElement(By.xpath("//android.widget.Button[@content-desc=\"Send\"]")).click();



	}
}

	   
	

