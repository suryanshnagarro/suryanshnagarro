package stepdefnitions;

import java.net.URL;
import java.util.concurrent.TimeUnit;


import org.openqa.selenium.By;
import org.openqa.selenium.remote.DesiredCapabilities;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import jdk.internal.jline.internal.Log;

public class hidingshowingbuttons 

{  
	private static AppiumDriver<MobileElement> driver;
	public static AppiumDriverLocalService service;
    // @Before
  //   public void startappium() {
  //  	 service = AppiumDriverLocalService.buildDefaultService();
  //  	 service.start();
    	// }
  //   @After
   //  public void closeappium1() {
    //	 service.stop();
    //	 driver.quit();
    //	 }
	//static Logger log = LogManager.getLogger( hidingshowingbuttons.class);
    	


	@Given("^I open the application$")
	public void i_open_the_application()throws Throwable {
	//	Log.info("opening the application");
		DesiredCapabilities capabilties = new DesiredCapabilities();
		
		capabilties.setCapability("platformName", "Android");
		capabilties.setCapability("platformVersion", "8.1");
		capabilties.setCapability("appPackage", "io.appium.android.apis");
		capabilties.setCapability("appActivity", ".ApiDemos");
		capabilties.setCapability("deviceName", "Android");
		capabilties.setCapability("app", "/Users/suryanshrastogi/Downloads/ApiDemos-debug.apk");
		
		try {
			driver = new AndroidDriver(new URL(("http://0.0.0.0:4723/wd/hub")),capabilties);
			driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);

			}catch (Exception e) {
			e.printStackTrace();
			}

	    
	  
	 
	   
	}
	    
	    
	

	@When("^I tap on Animation$")
	public void i_tap_on_Animation() throws Throwable {
		//Log.info("tap on animation");
		
		driver.findElement(By.xpath("//android.widget.TextView[@content-desc=\"Animation\"]")).click();
	    
	}

	@When("^I tap on Hide-Show Animations$")
	public void i_tap_on_Hide_Show_Animations() throws Throwable {
		//Log.info("tap on hideshow animation");
		driver.findElement(By.xpath("//android.widget.TextView[@content-desc=\"Hide-Show Animations\"]")).click();
	    
	}

	@Then("^I validate the hiding of buttons$")
	public void i_validate_the_hiding_of_buttons() throws Throwable {
		//Log.info("tap on hiding buttons");
		driver.findElement(By.xpath("	\r\n"
				+ "/hierarchy/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout[2]/android.widget.LinearLayout/android.widget.LinearLayout[3]/android.widget.Button[1]")).click();
	//	driver.findElement(By.xpath("	\r\n"
			//	+ "/hierarchy/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout[2]/android.widget.LinearLayout/android.widget.LinearLayout[3]/android.widget.Button[2]")).click();
	    		
	    			driver.findElement(By.xpath("	\r\n"
				+ "/hierarchy/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout[2]/android.widget.LinearLayout/android.widget.LinearLayout[3]/android.widget.Button[3]")).click();

	//	driver.findElement(By.xpath("	\r\n"
			//	+ "/hierarchy/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout[2]/android.widget.LinearLayout/android.widget.LinearLayout[3]/android.widget.Button[4]")).click();
	    	
	}

	@When("^I tap on first button$")
	public void i_tap_on_first_button() throws Throwable {
	//	Log.info("tap on the first button");
		driver.findElement(By.xpath("	\r\n"
				+ "/hierarchy/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout[2]/android.widget.LinearLayout/android.widget.LinearLayout[3]/android.widget.Button[1]")).click();

	    
	}






@Then("^I validate the showing of buttons$")
public void i_validate_the_showing_of_buttons() throws Throwable {

driver.findElement(By.id("io.appium.android.apis:id/addNewButton")).click();
//Log.info("sucessfully clicked on show button");
	   
	}
}






