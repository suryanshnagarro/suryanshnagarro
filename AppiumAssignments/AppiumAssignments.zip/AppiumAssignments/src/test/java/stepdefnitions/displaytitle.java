package stepdefnitions;

import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.DesiredCapabilities;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

public class displaytitle {
	
	private static AppiumDriver<MobileElement> driver;
	@When("^I tap on App$")
	public void i_tap_on_App()  
	{DesiredCapabilities capabilties = new DesiredCapabilities();
	
	capabilties.setCapability("platformName", "Android");
	capabilties.setCapability("platformVersion", "8.1");
	capabilties.setCapability("appPackage", "io.appium.android.apis");
	capabilties.setCapability("appActivity", ".ApiDemos");
	capabilties.setCapability("deviceName", "Android");
	capabilties.setCapability("app", "/Users/suryanshrastogi/Downloads/ApiDemos-debug.apk");
	
	try {
		driver = new AndroidDriver(new URL(("http://0.0.0.0:4723/wd/hub")),capabilties);
		driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);

		}catch (Exception e) {
		e.printStackTrace();
		}

		driver.findElement(By.xpath("//android.widget.TextView[@content-desc=\"App\"]")).click();
	    
	}


@When("^I tap on Action Bar$")
public void i_tap_on_Action_Bar() throws Throwable {
	driver.findElement(By.xpath("	\r\n"
			+ "//android.widget.TextView[@content-desc=\"Action Bar\"]")).click();
   
}

	    
	

	@Then("^I tap on Display options$")
	public void i_tap_on_Display_opstions() throws Throwable {
		driver.findElement(By.xpath("//android.widget.TextView[@content-desc=\"Display Options\"]")).click();
		
	    
	}

	@Then("^I tap on Display show title$")
	public void i_tap_on_Display_show_title() throws Throwable {
	    driver.findElementById("io.appium.android.apis:id/toggle_show_custom").click();
	    
	}

	


}
