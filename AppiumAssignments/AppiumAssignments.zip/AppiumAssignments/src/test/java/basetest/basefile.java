package basetest;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class basefile {
	public AppiumDriver <MobileElement> driver;


	static File file = new File("./resources/config.properties");
	static FileInputStream fis = null;

	static Properties prop = new Properties();

	static {

		try {
			fis = new FileInputStream(file);

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}

		try {
			prop.load(fis);
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
